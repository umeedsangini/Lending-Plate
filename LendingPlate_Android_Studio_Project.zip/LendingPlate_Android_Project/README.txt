LENDING PLATE — ANDROID STUDIO PROJECT

This is an Android WebView wrapper around the supplied Lending Plate HTML prototype.
The launcher app name and icon both display the words "Lending Plate".

BUILD APK:
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

Note: This package is the Android Studio project source, not a precompiled APK.
The included payment flow remains a local simulation and is not connected to a real bank/payment network.
